package com.carwatch.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

data class Zone(val id: String, val name: String, val lat: Double, val lng: Double, val phone: String)

// ===== عدّل هنا المناطق والأرقام ونصف القطر =====
val ZONES = listOf(
    Zone("mahmoud_zaid", "محمود زيد", 30.493301, 31.239275, "01017471837"),
    Zone("mohamed_mahgoub", "محمد محجوب", 30.556248, 31.211332, "+201003071069"),
    Zone("mohamed_elrekaby", "محمد الركايبى", 30.536935, 31.184288, "01016853202"),
)
const val RADIUS_METERS = 300f
const val COOLDOWN_MS = 60L * 60L * 1000L // مكالمة واحدة كل ساعة لكل منطقة
// ==============================================

object Geo {
    @SuppressLint("MissingPermission")
    fun register(ctx: Context) {
        val client = LocationServices.getGeofencingClient(ctx)
        val fences = ZONES.map {
            Geofence.Builder()
                .setRequestId(it.id)
                .setCircularRegion(it.lat, it.lng, RADIUS_METERS)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
                .build()
        }
        val request = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofences(fences)
            .build()
        val pi = PendingIntent.getBroadcast(
            ctx, 0, Intent(ctx, GeofenceReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        client.addGeofences(request, pi)
    }
}

class GeofenceReceiver : BroadcastReceiver() {
    @SuppressLint("MissingPermission")
    override fun onReceive(ctx: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        if (event.geofenceTransition != Geofence.GEOFENCE_TRANSITION_ENTER) return
        val prefs = ctx.getSharedPreferences("calls", Context.MODE_PRIVATE)
        event.triggeringGeofences?.forEach { g ->
            val zone = ZONES.find { it.id == g.requestId } ?: return@forEach
            val last = prefs.getLong(zone.id, 0L)
            if (System.currentTimeMillis() - last < COOLDOWN_MS) return@forEach
            prefs.edit().putLong(zone.id, System.currentTimeMillis()).apply()
            if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                ctx.getSystemService(TelecomManager::class.java)
                    .placeCall(Uri.parse("tel:" + zone.phone), Bundle())
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            try { Geo.register(ctx) } catch (_: Exception) { }
        }
    }
}

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            text = "اضغط تفعيل ثم وافق على كل الصلاحيات"
        }
        val btn = Button(this).apply {
            text = "تفعيل"
            setOnClickListener { step() }
        }
        root.addView(status)
        root.addView(btn)
        setContentView(root)
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun step() {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION) || !has(Manifest.permission.CALL_PHONE)) {
            requestPermissions(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.CALL_PHONE
            ), 1)
            return
        }
        if (Build.VERSION.SDK_INT >= 29 && !has(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
            status.text = "اختار \"السماح طوال الوقت\" للموقع"
            requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "فعّل \"العرض فوق التطبيقات الأخرى\" ثم ارجع واضغط تفعيل"
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            status.text = "اسمح للتطبيق يشتغل بدون توفير بطارية ثم ارجع واضغط تفعيل"
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            return
        }
        try {
            Geo.register(this)
            status.text = "تم التفعيل ✅\nالمراقبة شغالة على ${ZONES.size} مناطق"
        } catch (e: Exception) {
            status.text = "حصل خطأ: ${e.message}"
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        step()
    }
}
